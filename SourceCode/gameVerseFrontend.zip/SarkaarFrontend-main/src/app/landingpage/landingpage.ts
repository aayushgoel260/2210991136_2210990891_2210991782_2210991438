import { Component, ViewChild } from '@angular/core';
import { NgFor, NgIf, NgClass } from '@angular/common';
import { TeamCard } from '../team-card/team-card';
import { Timer } from '../timer/timer';
// ...existing code...

interface TeamData {
  teamId: string;
  name: string;
  balance: number;
  currentBid?: number;
}

@Component({
  selector: 'app-landingpage',
  imports: [TeamCard, NgFor, NgIf, NgClass, Timer],
  templateUrl: './landingpage.html',
  styleUrl: './landingpage.css',
  standalone: true
})
export class Landingpage {
  // Toaster state
  toasterMessage: string | null = null;
  toasterTimeout: any = null;
  teams: TeamData[] = [];

  // Bid interval (read from localStorage if set in team selection)
  bidInterval: number = 10;

  winnerModalOpen = false;
  winnerTeam: TeamData | null = null;
  hasPlayedAtLeastOneRound = false;

  // ...existing code...

  constructor() {
    // Try to read team names from localStorage
    const storedNames = localStorage.getItem('teamNames');
    let names: string[] = [];
    try {
      if (storedNames) {
        names = JSON.parse(storedNames);
      }
    } catch { }
    // Use provided names, fallback to default
    if (names.length >= 2 && names.length <= 10) {
      this.teams = names.map((name, idx) => ({
        teamId: String.fromCharCode(65 + idx),
        name,
        balance: 100000,
        currentBid: undefined
      }));
    } else {
      this.teams = [
        { teamId: 'A', name: 'Team A', balance: 100000, currentBid: undefined },
        { teamId: 'B', name: 'Team B', balance: 100000, currentBid: undefined },
        { teamId: 'C', name: 'Team C', balance: 100000, currentBid: undefined },
        { teamId: 'D', name: 'Team D', balance: 100000, currentBid: undefined }
      ];
    }
    // Read bid interval (stepCount) from localStorage if set in team selection
    const storedStep = localStorage.getItem('stepCount');
    if (storedStep) {
      const parsed = parseInt(storedStep, 10);
      if (!isNaN(parsed) && parsed > 0) {
        this.bidInterval = parsed;
      }
    }
    // ...existing code...
  }

  isGameLocked: boolean = false;
  activeTeam: string | null = null;
  @ViewChild('roundTimer') roundTimer?: Timer;

  // Checking whether all teams have placed a positive bid and
  // the maximum bid is unique (occurs exactly once)
  canLock(): boolean {
    const bids = this.teams.map(t => t.currentBid);
    // All teams must have entered a bid (including zero)
    if (bids.some(b => b === undefined || b === null)) return false;
    // Find all non-zero bids
    const nonZeroBids = bids.filter(b => typeof b === 'number' && b > 0) as number[];
    if (nonZeroBids.length === 0) return false; // At least one non-zero bid required
    // The maximum non-zero bid must be unique
    const max = Math.max(...nonZeroBids);
    const maxCount = nonZeroBids.filter(b => b === max).length;
    return maxCount === 1;
  }

  // Get the minimum allowed bid for a team (for increment button)
  getMinimumBid(teamId: string): number {
    // Find the current max non-zero bid among other teams
    const otherBids = this.teams.filter(t => t.teamId !== teamId).map(t => t.currentBid ?? 0);
    const maxOtherBid = Math.max(0, ...otherBids.filter(b => b > 0));
    return maxOtherBid + this.bidInterval;
  }

  onBidPlaced(amount: number, teamId: string) {
    const team = this.teams.find(t => t.teamId === teamId);
    if (!team) return;
    // Zero is always valid
    if (amount === 0) {
      team.currentBid = 0;
      console.log(`Team ${teamId} placed bid: 0. Can lock: ${this.canLock()}`);
      return;
    }
    // For non-zero bids, must be at least (maxOtherBid + bidInterval)
    const minBid = this.getMinimumBid(teamId);
    if (amount < minBid) {
      this.showToaster(`Bid must be at least ${minBid}`);
      return;
    }
    // Accept bid only if valid
    team.currentBid = amount;
    console.log(`Team ${teamId} placed bid: ${amount}. Can lock: ${this.canLock()}`);
  }

  showToaster(message: string) {
    this.toasterMessage = message;
    if (this.toasterTimeout) {
      clearTimeout(this.toasterTimeout);
    }
    this.toasterTimeout = setTimeout(() => {
      this.toasterMessage = null;
    }, 4500);
  }

  closeToaster() {
    this.toasterMessage = null;
    if (this.toasterTimeout) {
      clearTimeout(this.toasterTimeout);
      this.toasterTimeout = null;
    }
  }

  onTimerFinished() {
    // If timer finishes while bids are locked, auto-mark as wrong for active team
    if (this.isGameLocked && this.activeTeam) {
      console.log('Timer expired: auto-marking wrong for', this.activeTeam);
      this.handleAnswer(false, this.activeTeam);
    }
  }

  lockBids() {
    if (!this.canLock() || this.isGameLocked) return;
    // finding team with highest bid
    let max = -Infinity;
    let winner: TeamData | null = null;
    for (const t of this.teams) {
      if ((t.currentBid || 0) > max) {
        max = t.currentBid || 0;
        winner = t;
      }
    }
    if (winner) {
      this.isGameLocked = true;  // shows timer
      this.activeTeam = winner.teamId;
    }
  }

  handleAnswer(correct: boolean, teamId: string) {
    if (this.isProcessingResult) return;
    const team = this.teams.find(t => t.teamId === teamId);
    if (!team) return;
    const bidAmount = team.currentBid || 0;

    this.isProcessingResult = true;

    this._setResultState(teamId, correct ? 'correct' : 'wrong');

    // Wait for animation(yellow or green for incorrect or correct ), then apply balance change and reset UI
    setTimeout(() => {
      if (correct) {
        team.balance += bidAmount;
      } else {
        team.balance -= bidAmount;
      }

      this.teams.forEach(t => t.currentBid = 0);
      this.isGameLocked = false;
      this.activeTeam = null;
      if (this.roundTimer) {
        this.roundTimer.reset();
      }

      this.isProcessingResult = false;
      this.hasPlayedAtLeastOneRound = true;
    }, 3000);
  }

  isProcessingResult = false;
  results: Record<string, 'none' | 'correct' | 'wrong'> = {};

  private _setResultState(teamId: string, state: 'correct' | 'wrong') {
    this.results[teamId] = state;
    setTimeout(() => {
      this.results[teamId] = 'none';
    }, 3000);
  }

  showWinner() {
    // Find team with max balance (the actual winner of the game)
    let maxBalance = Math.max(...this.teams.map(t => t.balance));
    let winners = this.teams.filter(t => t.balance === maxBalance);
    this.winnerTeam = winners.length > 0 ? winners[0] : null;
    this.winnerModalOpen = true;
  }

  closeWinnerModal() {
    this.winnerModalOpen = false;
    this.winnerTeam = null;
  }

  // ...existing code...


}